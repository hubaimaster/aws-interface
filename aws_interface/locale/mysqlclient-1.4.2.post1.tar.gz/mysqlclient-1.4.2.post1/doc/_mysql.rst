_mysql Module
=============

.. automodule:: MySQLdb._mysql
    :members:
    :undoc-members:
    :show-inheritance:
