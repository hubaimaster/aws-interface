Welcome to MySQLdb's documentation!
===================================

Contents:

.. toctree::
    :maxdepth: 3

    user_guide
    MySQLdb
    FAQ

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

