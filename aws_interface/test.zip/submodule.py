

def get_answer(origin):
    return origin + 1
