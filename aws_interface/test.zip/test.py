import submodule


def handler(payload, user):
    return {
        'answer': submodule.get_answer(payload['answer'])
    }
